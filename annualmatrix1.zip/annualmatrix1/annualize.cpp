/*-
Annual transition matrix calculator
Copyright (C) 2008-2009 Shigeaki F. Hasegawa and Takenori Takada

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 3
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

Published research assisted by the annual transition matrix calculator
should use a statement similar to the following in the materials
and methods section "... analysis performed on a computer using
the public domain annual transition matrix calculation program
(developed by Takada, T and Hasegawa,S. F. and available on the
Internet at http://hosho.ees.hokudai.ac.jp/~takada/enews.html)".

May 15, 2009
Written by S. F. Hasegawa (shasegaw@chikyu.ac.jp).
-*/

#include "annualize.h"

// Constructor
Annualize::Annualize( const int _p_root, const int _m_size ){
	set_param( _p_root, _m_size );
}

void Annualize::set_param( const int _p_root, const int _m_size ){
	power_root = _p_root;
	matrix_size = _m_size;

	matrix_eigenvectors.resize( matrix_size, matrix_size );
	vector_eigenvalues.resize( matrix_size );
	matrix_inv_eigenvectors.resize( matrix_size, matrix_size );
	diagonalmatrix.resize( matrix_size, power_root );
}

void Annualize::calc_eigenvector( const CPPL::dgematrix &_given_matrix ){

	//Define working variables
	vector<double> wr, wi;
	vector<CPPL::dcovector> vrr, vri;
	int i,j;
	CPPL::dgematrix _matrix_copy = _given_matrix;

	// calc eigenvalues and eigenectors with LAPACK
	_matrix_copy.dgeev( wr, wi, vrr, vri );
	
	for ( i = 0; i < matrix_size ; i++ )
		for ( j = 0; j < matrix_size ; j++)
			matrix_eigenvectors( j, i ) = complex<double>( vrr[i](j), vri[i](j) );

	for ( i = 0; i < matrix_size ; i++ )
		vector_eigenvalues( i ) = complex<double>( wr[i], wi[i] );
}

void Annualize::calc_inv_eigenvector(){
	// Define working valiables
	int i, j;
	CPPL::zgematrix matrix_temp;
	CPPL::zcovector y( matrix_size );

	for ( i = 0; i < matrix_size; i++ ){
		matrix_temp = matrix_eigenvectors;
		for ( j = 0; j < matrix_size; j++ )
			if ( i == j )
				y( j ) = 1;
			else
				y( j ) = 0;

		matrix_temp.zgesv( y );

		for ( j = 0; j < matrix_size; j++ )
			matrix_inv_eigenvectors(j, i) = y(j);
	}
}

void Annualize::calc_diagonalmatrix( const int _flg ){
	//Define working variables
	int i, j;
	double complex_size, complex_argument;
	double angle;

	for ( i=0; i< vector_eigenvalues.l; i++ ){
		complex_argument = arg( vector_eigenvalues( i ) );
		complex_size = pow( abs( vector_eigenvalues( i ) ), (1.0/(double)power_root) );
		for ( j=0; j< power_root; j++ ){
			angle= ( complex_argument +  2*PI*j ) / (double)power_root;
			diagonalmatrix(i, j) = complex<double>(complex_size * cos( angle ), complex_size * sin( angle ) );
		}
	}
}

void Annualize::preparation( const CPPL::dgematrix &_given_matrix, const int _flg ){
	calc_eigenvector( _given_matrix );
	calc_inv_eigenvector();
	calc_diagonalmatrix( _flg );
}

CPPL::zgematrix Annualize::get_result( const Counter &_counter ) const{
	// Define temporal variables
	CPPL::zgematrix _tmp( matrix_size, matrix_size );
	CPPL::zgematrix _result( matrix_size, matrix_size );
	int i, j;

	for ( i = 0; i < matrix_size; i++ )
		for ( j = 0; j < matrix_size; j++)
			_tmp( j, i ) = matrix_eigenvectors( j, i ) * diagonalmatrix( i, _counter.get_num( i ) );
	_result = _tmp * matrix_inv_eigenvectors;

	return _result ;
}
