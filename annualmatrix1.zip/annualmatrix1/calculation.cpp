/*-
Annual transition matrix calculator
Copyright (C) 2008-2009 Shigeaki F. Hasegawa and Takenori Takada

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 3
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

Published research assisted by the annual transition matrix calculator
should use a statement similar to the following in the materials
and methods section "... analysis performed on a computer using
the public domain annual transition matrix calculation program
(developed by Takada, T and Hasegawa,S. F. and available on the
Internet at http://hosho.ees.hokudai.ac.jp/~takada/enews.html)".

May 15, 2009
Written by S. F. Hasegawa (shasegaw@chikyu.ac.jp).
-*/
#include <iostream>
#include "cpplapack.h"
#include "calculation.h"
#include <string>
#include <algorithm>
#include "filter.h"
#include "print_matrix.h"
#include "mod_neg_matrix.h"

bool Calculation::read_matrix_file( const char *_filename ){
	ifstream infile( _filename );
	// open input file stream
	if ( !infile ){
		// File open error
		cout << "Error: Cannot open input file; ";
		cout << _filename << endl;
		return ( false );
	}

	// define working variables
	char line[ MAX_LINE_LENGTH ];
	char *ptr;
	int matrix_column = 0;
	int i;
	vector<double> store_data;

	while ( !infile.eof() ){
		// read one line from stream
		infile.getline( line, MAX_LINE_LENGTH );
		store_data.clear();
		// divide line by ","
		ptr = strtok( line, "," );
		while ( ptr != NULL ){
			store_data.push_back( atof( ptr ) );
			ptr = strtok( NULL, ",");
		}
		if ( matrix_column == 0 )
			// resize matrix according to the number of rows
			// in the first column
			given_matrix.resize( store_data.size(), store_data.size() );
		if (store_data.size() > 0 ){
			matrix_column += 1;
			for ( i=0; i< (int)store_data.size() ; i++)
				given_matrix( i, matrix_column-1 ) = store_data[ i ];
		}
	}
	// check input data
	if ( given_matrix.m != given_matrix.n ){
		cout << "Error: Given matrix is not square!"<<endl;
		return ( false );
	}
	// check input data
	if ( matrix_column < 2 ){
		cout << "Error: Input file is empty"<<endl;
		return ( false );
	}
	infile.close();
	return( true );
}

bool Calculation::read_area_file( const char *_filename ){
	ifstream infile( _filename );
	if ( !infile ){
		// File open error
		cout << "Error: Cannot open area file; ";
		cout << _filename << endl;
		return ( false );
	}

	char line[ MAX_LINE_LENGTH ];
	char *ptr;
	int i;
	vector<double> _init_data;
	vector<double> _fin_data;

	while ( !infile.eof() ){
		// read one line from input file stream
		infile.getline( line, MAX_LINE_LENGTH );
		i = 0;
		// divide line by ","
		ptr = strtok( line, "," );
		while ( ptr != NULL ){
			if( i == 0 )
				// first line include initial area data
				_init_data.push_back( atof( ptr ) );
			if( i == 1 )
				// second line include final area data
				_fin_data.push_back( atof( ptr ) );
			ptr = strtok( NULL, ",");
			i += 1;
		}
	}

	// copy data from vector<double> to CPPL::dcovector object
	initial_area.resize( _init_data.size() );
	final_area.resize( _fin_data.size() );
	for( i = 0; i < (int)_init_data.size(); i++)
		initial_area( i ) = _init_data[ i ];
	for( i = 0; i < (int)_fin_data.size(); i++)
		final_area( i ) = _fin_data[ i ];

	// check if the length of area vector
	// is equal to the number of rows in given matrix
	if ( (int)_init_data.size() != given_matrix.m ){
		cout << "Error: Number of column do not match with matrix" << endl;
		return ( false );
	}

	infile.close();
	return( true );
}

void Calculation::print_given_matrix() const{
	print_matrix( given_matrix );
}

void Calculation::prep(){
	annual_data.set_param( power_root, given_matrix.m );
	annual_data.preparation( given_matrix, trans_flg );

	counter.reset( given_matrix.m, power_root );
}

void Calculation::run_calc(){
	CPPL::zgematrix _buf( given_matrix.m, given_matrix.m);
	while( !counter.finish() ){
		_buf = annual_data.get_result( counter ) ;
		// check if acquired result is real matrix or not
		if( real( _buf ) )
			results.push_back( _buf );
		counter.plus( trans_flg );
	}
}

long Calculation::estimate_speed(){
	long speed = 0;
	clock_t start_time;	// count number of calculation
	CPPL::zgematrix _buf( given_matrix.m, given_matrix.m);

	// count how many trials are possibe in one second
	start_time = clock();
	while( (clock() - start_time ) < CLOCKS_PER_SEC && !counter.finish() ){
		_buf = annual_data.get_result( counter ) ;
		if( real( _buf ) )
			results.push_back( _buf );
		counter.plus( trans_flg );
		speed += 1;
	}

	// check if all the calculation is finished in one second or not.
	if( counter.finish() )
		return( -1 );
	else
		return speed;
}

int Calculation::matrix_size() const{
	return given_matrix.m;
}

int Calculation::num_positive_results() const{
	return count_if( results.begin(), results.end(), positive );
}

int Calculation::num_real_results() const{
	return results.size();
}

int Calculation::num_small_negative_results() const{
	return count_if( results.begin(), results.end(), small_negative );
}


bool Calculation::write_all_results( const char *_filename ){
	ofstream outfile( _filename );
	list<CPPL::zgematrix>::iterator Ptr;

	if ( !outfile ){
		// File open error
		cout << "Error: Cannot open output file; ";
		cout << _filename << endl;
		return ( false );
	}


	// summary of the results
	outfile << "Summary: " << endl << endl;
	outfile << "Input matrix is:"<<endl;
	print_matrix( given_matrix, outfile );
	outfile << "Power root is: " << power_root <<endl;
	outfile << "The number of matrices with real elements is ";
	outfile << num_real_results() << endl;
	outfile << "The number of matrices with positive elements is ";
	outfile << num_positive_results() << endl;
	outfile << "The number of matrices ";
	outfile << "with a few small negative elements is ";
	outfile << num_small_negative_results() - num_positive_results() ;
	outfile << endl << endl;

	// matrices with real elements
	outfile <<"#########"<<endl;
	outfile << "Obtained matrices with real elements." << endl;
	for( Ptr = results.begin(); Ptr != results.end(); Ptr++ )
		print_matrix( *Ptr, outfile );

	// matrices with positive elements
	outfile <<"#########"<<endl;
	summary_positive_results( outfile );

	// matrices with a few negative elements
	outfile <<"#########"<<endl;
	summary_small_negative_results( outfile );

	cout <<"Calculation finished"<<endl;

	outfile.close();
	return( true );
}

void Calculation::summary_small_negative_results( ofstream &fout ){
	list<CPPL::zgematrix>::iterator pItr;
	CPPL::dgematrix _temp;
	int _counter = 0;
	int i;
	char _sout[64];

	if( num_positive_results() - num_small_negative_results() == 0 )
		fout << "No matrix with a few small negative elements." << endl;
	else{
		fout << "Matrices with a few small negative elements." << endl;
		if( num_small_negative_results() > 1 )
			fout << "*** Warning: Plural solutions ***" << endl;
		for( pItr = results.begin(); pItr != results.end(); pItr++){
			if( !positive(*pItr) && small_negative(*pItr) ){
				_counter += 1;
				fout << "-------------" << endl;
				fout << "Result. " << _counter <<endl;
				//////////////////////
				fout << "Obtained annual matrix;" <<endl;
				print_matrix( *pItr, fout );
				/////////////////////
				fout << "Calibrated annual matrix;"<<endl;
				_temp = modify_negative_matrix( *pItr );
				print_matrix( _temp, fout );

				if( initial_area.l > 0 ){
					// Error estimation.
					CPPL::dgematrix _buf( given_matrix.m, given_matrix.n);
					CPPL::dcovector _vec( given_matrix.m );

					_buf = _temp;
					_vec = initial_area;

					// multiply calibrated annual matrix
					// to the vector of initial area.
					for( i = 0; i < power_root; i++)
						_vec = _buf*_vec;

					fout << "Error estimation:"<<endl;

					fout << "area," ;
					for( i = 0; i < _vec.l ; i++ ){
						fout << "col." << i+1;
						if( i != _vec.l -1 )
							fout << ",";
						else
							fout << endl;
					}
					fout << "Start," ;
					for( i = 0; i < initial_area.l ; i++ ){
						fout << initial_area( i );
						if( i != initial_area.l - 1)
							fout << ",";
						else
							fout << endl;
					}
					fout << "End," ;
					for( i = 0; i < final_area.l ; i++ ){
						fout << final_area( i );
						if( i != final_area.l - 1)
							fout << ",";
						else
							fout << endl;
					}
					fout << "Estimate," ;
					for( i = 0; i < _vec.l ; i++ ){
						fout << _vec( i );
						if( i != _vec.l -1 )
							fout << ",";
						else
							fout << endl;
					}

					// sum up all final_area
					double final_area_all = 0.0;
					for( i =0; i < final_area.l; i++ )
						final_area_all += final_area( i );

					fout << "errors(%),";
					for( i = 0; i < _vec.l ; i++ ){
						sprintf( _sout, "%2.3f", ( _vec( i ) - final_area( i ) ) / final_area_all * 100 );
						fout << _sout;
						if( i != _vec.l -1 )
							fout << ",";
						else
							fout << endl;

					}
					fout << endl;
				}
			}
		}
	}
}

void Calculation::summary_positive_results( ofstream &fout ){
	if( num_positive_results() == 0 )
		fout << "No matrix with positive elements." << endl;
	else{
		list<CPPL::zgematrix>::iterator pItr;
		fout << "Matrices with positive elements;" << endl;
		if( num_positive_results() > 1 )
			fout << "*** Warning: Plural solutions ***" << endl;

		for( pItr = results.begin(); pItr != results.end(); pItr++)
			if( positive(*pItr) )
				print_matrix( *pItr, fout );
	}
	fout << endl;
}

