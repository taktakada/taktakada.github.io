/*-
Annual transition matrix calculator
Copyright (C) 2008-2009, Shigeaki F. Hasegawa and Takenori Takada

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 3
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

Published research assisted by the annual transition matrix calculator
should use a statement similar to the following in the materials
and methods section "... analysis performed on a computer using
the public domain annual transition matrix calculation program
(developed by Takada, T and Hasegawa,S. F. and available on the
Internet at http://hosho.ees.hokudai.ac.jp/~takada/enews.html)".

May 15, 2009
Written by S. F. Hasegawa (shasegaw@chikyu.ac.jp).
-*/
#include "cpplapack.h"
#include <complex>
#include "counter.h"

using namespace std;

#if !defined(__ANNUALIZE_H)
#define __ANNUALIZE_H

#define PI 3.14159265358979

class Annualize{
	int power_root, matrix_size;
	CPPL::zgematrix matrix_eigenvectors;
	CPPL::zcovector vector_eigenvalues;
	CPPL::zgematrix matrix_inv_eigenvectors;
	CPPL::zgematrix diagonalmatrix;
public:
	Annualize(){};		// Constructer. Do nothing.
	Annualize( const int _p_root, const int _m_size );	// Constructer with root number and matrix size
	~Annualize(){};		// Do nothing :-)

	void set_param( const int _p_root, const int _m_size);
	void calc_eigenvector( const CPPL::dgematrix &_given_matrix );
	void calc_inv_eigenvector();
	void calc_diagonalmatrix( const int _flg );

	void preparation( const CPPL::dgematrix &_given_matrix, const int _flg );

	CPPL::zgematrix get_result( const Counter &_counter ) const;
};

#endif	/* __ANNUALIZE_H */
