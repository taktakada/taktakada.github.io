/*-
Annual transition matrix calculator
Copyright (C) 2008-2009 Shigeaki F. Hasegawa and Takenori Takada

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 3
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

Published research assisted by the annual transition matrix calculator
should use a statement similar to the following in the materials
and methods section "... analysis performed on a computer using
the public domain annual transition matrix calculation program
(developed by Takada, T and Hasegawa,S. F. and available on the
Internet at http://hosho.ees.hokudai.ac.jp/~takada/enews.html)".

May 15, 2009
Written by S. F. Hasegawa (shasegaw@chikyu.ac.jp).
-*/
#include "cpplapack.h"
#include "calculation.h"

using namespace std;

int main(int argc, char *argv[]);

int main(int argc, char *argv[]){
	// the number of options is 4 or 5
	if (argc < 4 || argc > 5 ){
		cout << "Usage: "<< argv[0] ;
		cout << " infile years outfile [areafile]" << endl;
		return ( -1 );
	}

	int power_root = atoi( argv[2] );
	if ( power_root <= 0 ){
		cout <<"Error: given power root is not >0"<<endl;
		return ( -1 );
	}

	Calculation calc( power_root );

	calc.read_matrix_file( argv[1] );
	if( argc == 5 )
		calc.read_area_file( argv[4] );

	// confirm input data
	cout << "Given matrix is:"<<endl;
	calc.print_given_matrix();
	cout <<endl;

	double calc_num = (double)calc.matrix_size();

	cout <<"###############################"<<endl;
	cout << "Given power root is: ";
	cout << power_root << endl<<endl;
	cout <<"###############################"<<endl;

	// prepare for calculation.
	calc.prep();

	// estimate calculation time.
	// Count number of calculation in one second
	long speed = calc.estimate_speed(); 
	if( speed != -1 ){
		double estimate = pow(10, calc_num  * log10( (double)power_root ) - log10( (double)speed ) ) - 1;

		int hour, min, sec;
		hour = (int)estimate/3600;
		min = ((int)estimate - hour*3600)/60;
		sec = (int)estimate - hour*3600 - min*60;

		cout << "Estimated calculation time; ";
		cout << hour << "h";
		cout << min << "m";
		cout << sec << "s"<<endl;
		cout << endl;

		cout <<"###############################"<<endl;

		// Run rest of calculation.
		calc.run_calc();
	}
	calc.write_all_results( argv[3] );

	return( 0 );
}
