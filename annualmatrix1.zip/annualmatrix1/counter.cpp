/*-
Annual transition matrix calculator
Copyright (C) 2008-2009 Shigeaki F. Hasegawa and Takenori Takada

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 3
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

Published research assisted by the annual transition matrix calculator
should use a statement similar to the following in the materials
and methods section "... analysis performed on a computer using
the public domain annual transition matrix calculation program
(developed by Takada, T and Hasegawa,S. F. and available on the
Internet at http://hosho.ees.hokudai.ac.jp/~takada/enews.html)".

May 15, 2009
Written by S. F. Hasegawa (shasegaw@chikyu.ac.jp).
-*/
#include "counter.h"

// constructor
Counter::Counter( const int _matrix_size, const int _power_root ){
	counter.resize( _matrix_size, 0 );
	power_root = _power_root;
}

// reset counter
void Counter::reset( const int _matrix_size, const int _power_root ){
	counter.resize( _matrix_size, 0 );
	power_root = _power_root;
}

// proceed counter
void Counter::plus( const int _flg ){
	int i;
	counter[ 0 ] += 1;

	for( i = 0; i < (int)counter.size() -1 ; i++ )
		if( counter[ i ] == power_root ){
			counter[ i ] = 0;
			counter[ i+1 ] += 1;
		}
}

bool Counter::finish(){
	return ( counter.back() >= power_root );
}
