/*-
Annual transition matrix calculator
Copyright (C) 2008-2009 Shigeaki F. Hasegawa and Takenori Takada

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 3
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

Published research assisted by the annual transition matrix calculator
should use a statement similar to the following in the materials
and methods section "... analysis performed on a computer using
the public domain annual transition matrix calculation program
(developed by Takada, T and Hasegawa,S. F. and available on the
Internet at http://hosho.ees.hokudai.ac.jp/~takada/enews.html)".

May 15, 2009
Written by S. F. Hasegawa (shasegaw@chikyu.ac.jp).
-*/
#include <iostream>
#include "cpplapack.h"

using namespace std;

#if !defined(__PRINT_MATRIX_H)
#define __PRINT_MATRIX_H

void print_matrix( const CPPL::zgematrix &_buf, ofstream &_out );
void print_matrix( const CPPL::dgematrix &_buf, ofstream &_out );
void print_matrix( const CPPL::zgematrix &_buf, ofstream &_out, char *_msg );
void print_matrix( const CPPL::dgematrix &_buf, ofstream &_out, char *_msg );
void print_matrix( const CPPL::zgematrix &_buf );
void print_matrix( const CPPL::dgematrix &_buf );

#endif	/* __PRINT_MATRIX_H */
