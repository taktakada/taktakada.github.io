/*-
Annual transition matrix calculator
Copyright (C) 2008-2009 Shigeaki F. Hasegawa and Takenori Takada

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 3
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

Published research assisted by the annual transition matrix calculator
should use a statement similar to the following in the materials
and methods section "... analysis performed on a computer using
the public domain annual transition matrix calculation program
(developed by Takada, T and Hasegawa,S. F. and available on the
Internet at http://hosho.ees.hokudai.ac.jp/~takada/enews.html)".

May 15, 2009
Written by S. F. Hasegawa (shasegaw@chikyu.ac.jp).
-*/
#include "mod_neg_matrix.h"

using namespace std;

CPPL::dgematrix modify_negative_matrix( const CPPL::zgematrix &_matrix ){
	int i,j;
	bool neg_flg;
	double _sum;
	CPPL::dgematrix _buf(_matrix.m, _matrix.n);

	for( i = 0; i < _matrix.n ; i++ ){
		_sum = 0.0;
		neg_flg = false;

		for( j = 0; j < _matrix.m; j++ )
			if( _matrix( j , i ).real() < 0.0 ){
				_sum -= _matrix( j, i ).real();
				neg_flg = true;
			}

		if ( neg_flg )
			for( j = 0; j < _matrix.m; j++ )
				if( _matrix( j, i ).real() >= 0.0 )
					_buf( j, i ) = _matrix( j, i ).real() - _sum * (_matrix( j, i ).real() / ( 1.0 - _sum ) );
				else
					_buf( j, i ) = 0.0;
		else
			for( j = 0; j < _matrix.m; j++ )
				_buf( j, i ) = _matrix( j, i ).real();
	}
	return _buf;
}
