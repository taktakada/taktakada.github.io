/*-
Annual transition matrix calculator
Copyright (C) 2008-2009 Shigeaki F. Hasegawa and Takenori Takada

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 3
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

Published research assisted by the annual transition matrix calculator
should use a statement similar to the following in the materials
and methods section "... analysis performed on a computer using
the public domain annual transition matrix calculation program
(developed by Takada, T and Hasegawa,S. F. and available on the
Internet at http://hosho.ees.hokudai.ac.jp/~takada/enews.html)".

May 15, 2009
Written by S. F. Hasegawa (shasegaw@chikyu.ac.jp).
-*/

#include <iostream>
#include "cpplapack.h"
#include <list>
#include "counter.h"
#include "annualize.h"

using namespace std;

#if !defined(__CALCULATION_H)
#define __CALCULATION_H

#define MAX_LINE_LENGTH 1024

class Calculation{
	int power_root;		// Power root number
	CPPL::dgematrix given_matrix;	// store given matrix
	list<CPPL::zgematrix> results;	// store results
	int trans_flg;		// given matrix is transition matrix or not
	Counter counter;
	Annualize annual_data;
	CPPL::dcovector initial_area;
	CPPL::dcovector final_area;
public:

	Calculation(){};
	Calculation( int _n ){ power_root = _n; };	// Constructer with power root number
	~Calculation(){};		// Do nothing :-)

	void set_power_root( int _n ){ power_root = _n; };	// set power root number
	bool read_matrix_file( const char *_filename );	// read given matrix from file
	bool read_area_file( const char *_filename );

	void print_given_matrix() const;
	//bool check_trans_matrix();	// check if given matrix is transition matrix or not.
	void prep();	// preparation for calculation
	void run_calc();	// run calculation
	long estimate_speed();	// estimate number of calculation per second

	int matrix_size() const;
	int num_positive_results() const;
	int num_real_results() const;
	int num_small_negative_results() const;

	bool write_all_results( const char *_filename );

	void summary_positive_results( ofstream &fout );
	void summary_small_negative_results( ofstream &fout);
};

#endif	/* CALCULATION_H */
