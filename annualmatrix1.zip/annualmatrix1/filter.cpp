/*-
Annual transition matrix calculator
Copyright (C) 2008-2009 Shigeaki F. Hasegawa and Takenori Takada

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 3
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

Published research assisted by the annual transition matrix calculator
should use a statement similar to the following in the materials
and methods section "... analysis performed on a computer using
the public domain annual transition matrix calculation program
(developed by Takada, T and Hasegawa,S. F. and available on the
Internet at http://hosho.ees.hokudai.ac.jp/~takada/enews.html)".

May 15, 2009
Written by S. F. Hasegawa (shasegaw@chikyu.ac.jp).
-*/
#include <cmath>
#include "filter.h"

using namespace std;

// check if the matrix is constituted with real elements or not.
bool real( const CPPL::zgematrix &matrix_A){
	int i,j;
	double sum_imag = 0.0, sum_real = 0.0;
	for ( i=0; i< matrix_A.m; i++ )
		for ( j=0; j<matrix_A.m; j++ ){
			sum_imag += abs( matrix_A( i, j ).imag() );
			sum_real += matrix_A( i, j ).real();
		}
	// regard the matrix is "real"
	// if the sum of imaginaly part of elements is quite small
	return ( sum_imag < 0.0001 && sum_real > 0 );
}

// check if the matrix is constituted with positive elements
bool positive( const CPPL::zgematrix &matrix_A ){
	bool flg = true;
	int i, j;
	for( i = 0; i < matrix_A.m; i++)
		for( j=0; j < matrix_A.m; j++)
			if( matrix_A( i, j ).real() < 0.0  )
				flg = false;
	return( flg );
}

// check if the matrix is constituted with small negative elements
bool small_negative( const CPPL::zgematrix &matrix_A ){
	bool flg = true;
	int i, j;
	for( i = 0; i < matrix_A.m; i++)
		for( j=0; j < matrix_A.m; j++)
			if( matrix_A( i, j ).real() < -0.1  )
				flg = false;
	return( flg );
}

